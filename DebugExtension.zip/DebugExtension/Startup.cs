﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System.Net.WebSockets;
using System.Net.Sockets;
using System.Threading;
using System.Text;
using System.Net;

namespace DebugExtension
{
    public class Startup
    {
        private const int MAX_BUFFER_SIZE = 1024;
        private const int CLOSE_TASK_TIMEOUT_IN_MILLISECONDS = 5000;
        private const String JDWPHandshake = "JDWP-Handshake";
        private const String HTTP_PLATFORM_DEBUG_PORT = "HTTP_PLATFORM_DEBUG_PORT";

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
        }

        /**
        *  DebugSessionState holds the websocket and 
        *  debuggeeSocket that are part of a debug session.
        */
        class DebugSessionState
        {
            public Socket DebuggeeSocket { get; private set; }
            public WebSocket DebuggerWebSocket { get; private set; }
            public byte[] Buffer { get; private set; }

            public DebugSessionState(Socket debuggeeSocket, WebSocket webSocket)
            {
                DebuggeeSocket = debuggeeSocket;
                DebuggerWebSocket = webSocket;
                Buffer = new byte[MAX_BUFFER_SIZE];
            }
        }

        /**
         * OnDataReceiveFromDebuggee is the async callback called when
         * we have data from debuggeeSocket. On receiving data from debuggee,
         * we forward it on the webSocket to the debugger and issue the next
         * async read on the debuggeeSocket.
         */
        private async static void OnDataReceiveFromDebuggee(IAsyncResult result)
        {
            var debugSessionState = (DebugSessionState)result.AsyncState;
            try
            {
                var bytesRead = debugSessionState.DebuggeeSocket.EndReceive(result);
                if (bytesRead > 0)
                {
                    //
                    // got data from debuggee, need to write it to websocket.
                    //

                    if (debugSessionState.DebuggerWebSocket.State == WebSocketState.Open)
                    {
                        ArraySegment<byte> outputBuffer = new ArraySegment<byte>(debugSessionState.Buffer,
                                                                                 0,
                                                                                 bytesRead);
                        await debugSessionState.DebuggerWebSocket.SendAsync(outputBuffer,
                                                                            WebSocketMessageType.Binary,
                                                                            true,
                                                                            CancellationToken.None);
                    }
                }

                //
                // issue next read from debuggee socket
                //

                if (debugSessionState.DebuggeeSocket.Connected)
                {
                    debugSessionState.DebuggeeSocket.BeginReceive(debugSessionState.Buffer,
                                                                  0,
                                                                  debugSessionState.Buffer.Length,
                                                                  SocketFlags.None,
                                                                  OnDataReceiveFromDebuggee,
                                                                  debugSessionState);
                }
            }
            catch (Exception)
            {
                try
                {
                    Task closeTask = debugSessionState.DebuggerWebSocket.CloseAsync(WebSocketCloseStatus.InternalServerError,
                                                                   "Error communicating with debuggee.",
                                                                   CancellationToken.None);
                    closeTask.Wait(CLOSE_TASK_TIMEOUT_IN_MILLISECONDS);
                }
                catch (Exception) { /* catch all since if close fails, we need to move on. */ }
                if (debugSessionState.DebuggeeSocket != null)
                {
                    try
                    {
                        debugSessionState.DebuggeeSocket.Close();
                    }
                    catch (Exception) { /* catch all since if close fails, we need to move on. */ }
                }
            }
        }

        private async Task HandleWebSocketConnection(WebSocket webSocket)
        {
            Socket debuggeeSocket = null;
            String exceptionMessage = "Connection failure. ";
            try
            {
                string ipAddress = "127.0.0.1";
                try
                {
                    ipAddress = Environment.GetEnvironmentVariable("REMOTE_CONTROL_IP");
                }
                catch(Exception)
                {
                    ipAddress = "127.0.0.1";
                }

                if(ipAddress == null)
                {
                    ipAddress = "127.0.0.1";
                }

                /*
                int debugPort = Int32.Parse(Environment.GetEnvironmentVariable("REMOTE_CONTROL_PORT"));

                if (debugPort <= 0)
                {
                    throw new Exception("Debuggee not found. Please start your site in debug mode and then attach debugger.");
                }
                */
                int debugPort = 5858;

                //
                // Define a maximum message size this handler can receive (1K in this case) 
                // and allocate a buffer to contain the received message. 
                // This buffer will be reused for each receive operation.
                //

                DebugSessionState debugSessionState = null;

                if (debuggeeSocket == null)
                {
                    debuggeeSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    if (!debuggeeSocket.Connected)
                    {
                        debuggeeSocket.SetSocketOption(SocketOptionLevel.Tcp, SocketOptionName.NoDelay, true);
                        debuggeeSocket.Connect(new IPEndPoint(IPAddress.Parse(ipAddress), debugPort));
                        debugSessionState = new DebugSessionState(debuggeeSocket, webSocket);

                        debugSessionState.DebuggeeSocket.BeginReceive(debugSessionState.Buffer,        // receive buffer
                                                                       0,                               // offset
                                                                       debugSessionState.Buffer.Length, // length of buffer
                                                                       SocketFlags.None,
                                                                       OnDataReceiveFromDebuggee,       // callback
                                                                       debugSessionState);              // state
                    }
                    else
                    {
                        // duplicate handshake.
                        // will just let the jvm/debugger decide what to do.
                    }
                }

                byte[] receiveBuffer = new byte[MAX_BUFFER_SIZE];

                //
                // While the WebSocket connection remains open we run a simple loop that receives messages.
                // If a handshake message is received, connect to the debug port and forward messages to/from
                // the debuggee.
                //

                while (webSocket.State == WebSocketState.Open)
                {
                    // await message from websocket.
                    WebSocketReceiveResult receiveResult = await webSocket.ReceiveAsync(new ArraySegment<byte>(receiveBuffer),
                                                                                        CancellationToken.None);

                    if (receiveResult.MessageType == WebSocketMessageType.Close)
                    {
                        break;
                    }
                    else
                    {
                        int receivedBytes = receiveResult.Count;
                        if (receivedBytes > 0)
                        {
                            if (debuggeeSocket == null)
                            {
                                debuggeeSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                                if (!debuggeeSocket.Connected)
                                {
                                    debuggeeSocket.SetSocketOption(SocketOptionLevel.Tcp, SocketOptionName.NoDelay, true);
                                    debuggeeSocket.Connect(new IPEndPoint(IPAddress.Parse(ipAddress), debugPort));
                                    debugSessionState = new DebugSessionState(debuggeeSocket, webSocket);

                                    debugSessionState.DebuggeeSocket.BeginReceive(debugSessionState.Buffer,        // receive buffer
                                                                                   0,                               // offset
                                                                                   debugSessionState.Buffer.Length, // length of buffer
                                                                                   SocketFlags.None,
                                                                                   OnDataReceiveFromDebuggee,       // callback
                                                                                   debugSessionState);              // state
                                }
                                else
                                {
                                    // duplicate handshake.
                                    // will just let the jvm/debugger decide what to do.
                                }
                            }

                            // if send fails, it will throw and we release all resources below.
                            debuggeeSocket.Send(receiveBuffer, 0, receivedBytes, SocketFlags.None);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                // catch all Exceptions as we dont want the server to crash on exceptions.
                Console.WriteLine("HandleWebSocket connection exception: " + e);
                exceptionMessage += e.Message;
            }
            finally
            {
                try
                {
                    Task closeTask = webSocket.CloseAsync(WebSocketCloseStatus.InternalServerError,
                                                          exceptionMessage,
                                                          CancellationToken.None);
                    closeTask.Wait(CLOSE_TASK_TIMEOUT_IN_MILLISECONDS);
                }
                catch (Exception) { /* catch all since if close fails, we need to move on. */ }
                if (debuggeeSocket != null)
                {
                    try
                    {
                        debuggeeSocket.Close();
                        debuggeeSocket = null;
                    }
                    catch (Exception) { /* catch all since if close fails, we need to move on. */ }
                }
            }
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            var webSocketOptions = new WebSocketOptions()
            {
                KeepAliveInterval = TimeSpan.FromSeconds(120),
                ReceiveBufferSize = 4 * 1024
            };
            app.UseWebSockets(webSocketOptions);

            app.Use(async (context, next) =>
            {
                    if (context.WebSockets.IsWebSocketRequest)
                    {
                        WebSocket webSocket = await context.WebSockets.AcceptWebSocketAsync();
                        await HandleWebSocketConnection(webSocket);
                    }
                    else
                    {
                        context.Response.StatusCode = 400;
                    }
            });
        }
    }
}
